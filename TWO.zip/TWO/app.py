# main.py
from flask import Flask, request, jsonify
from models import db, Usuario, Pedido, Produto, PedidoProduto
from sqlalchemy.exc import IntegrityError

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:@localhost/api'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

@app.route('/api/adicionar_usuario', methods=['POST'])
def adicionar_usuario():
    try:
        data = request.get_json()
        novo_usuario = Usuario(nome=data['nome'], email=data['email'], idade=data['idade'])
        db.session.add(novo_usuario)
        db.session.commit()
        return jsonify(message="Usuário adicionado com sucesso!"), 201
    except IntegrityError:
        db.session.rollback()
        return jsonify(error="Erro ao adicionar usuário. Email já existe."), 400

@app.route('/api/buscar_usuario', methods=['GET'])
def buscar_usuario():
    email = request.args.get('email')
    usuario = Usuario.query.filter_by(email=email).first()
    if usuario:
        return jsonify(nome=usuario.nome, email=usuario.email, idade=usuario.idade), 200
    else:
        return jsonify(error="Usuário não encontrado."), 404

@app.route('/api/adicionar_pedido', methods=['POST'])
def adicionar_pedido():
    try:
        data = request.get_json()
        usuario = Usuario.query.get(data['usuario_id'])
        if not usuario:
            return jsonify(error="Usuário não encontrado."), 404

        novo_pedido = Pedido(usuario_id=data['usuario_id'], descricao=data['descricao'], status=data['status'])
        db.session.add(novo_pedido)
        db.session.commit()
        return jsonify(message="Pedido adicionado com sucesso!"), 201
    except IntegrityError:
        db.session.rollback()
        return jsonify(error="Erro ao adicionar pedido. Verifique os dados e tente novamente."), 400
    except Exception as e:
        db.session.rollback()
        return jsonify(error=str(e)), 500

@app.route('/api/listar_pedidos', methods=['GET'])
def listar_pedidos():
    pedidos = Pedido.query.all()
    resultados = [
        {"id": pedido.id, "usuario_id": pedido.usuario_id, "descricao": pedido.descricao, "status": pedido.status}
        for pedido in pedidos
    ]
    return jsonify(resultados), 200

@app.route('/api/adicionar_produto_pedido', methods=['POST'])
def adicionar_produto_pedido():
    try:
        data = request.get_json()
        pedido_id = data['pedido_id']
        produto_id = data['produto_id']

        # Encontra o pedido e produto pelos IDs fornecidos
        pedido = Pedido.query.get(pedido_id)
        produto = Produto.query.get(produto_id)

        if pedido is None or produto is None:
            return jsonify(error="Pedido ou produto não encontrado."), 404

        # Associa o produto ao pedido
        pedido.produtos.append(produto)
        db.session.commit()
        return jsonify(message="Produto adicionado ao pedido com sucesso!"), 201

    except Exception as e:
        db.session.rollback()
        return jsonify(error=str(e)), 400


if __name__ == '__main__':
    app.run(debug=True)

