CREATE DATABASE api;

USE api;

-- Table for storing user information
CREATE TABLE usuario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    idade INT
);

-- Table for storing product information
CREATE TABLE produto (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    preco DECIMAL(10, 2) NOT NULL,
    usuario_id INT, -- Assuming products are linked to users; if not needed, remove this line.
    FOREIGN KEY (usuario_id) REFERENCES usuario(id)
);

-- Table for storing order information
CREATE TABLE pedido (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT,
    descricao TEXT,
    status VARCHAR(50) CHECK (status IN ('pending', 'completed', 'cancelled')), -- Example of how to use a CHECK constraint
    FOREIGN KEY (usuario_id) REFERENCES usuario(id)
);

CREATE TABLE pedidoproduto (
    pedido_id INT,
    produto_id INT,
    PRIMARY KEY (pedido_id, produto_id),
    FOREIGN KEY (pedido_id) REFERENCES Pedido(id),
    FOREIGN KEY (produto_id) REFERENCES Produto(id)
);
