import mysql.connector
from mysql.connector import Error

# Conexão com o banco de dados
try:
    connection = mysql.connector.connect(
        host='localhost',  # Ou o endereço IP do seu servidor de banco de dados
        database='api',
        user='root',
        password='')

    # Cursor para executar consultas SQL
    cursor = connection.cursor()

    # Dados simulados de IDs de usuários e produtos para criar pedidos
    # Substitua isso por consultas ao banco de dados para buscar IDs reais, se necessário
    usuarios_ids = [1, 2, 3, 4, 5]  # IDs de usuários
    produtos_ids = [[1, 2], [2, 3], [3, 4], [4, 5], [5, 1]]  # IDs de produtos por pedido

    # Criar pedidos para cada usuário com produtos específicos
    for i, usuario_id in enumerate(usuarios_ids):
        # Inserir pedido
        cursor.execute("INSERT INTO pedido (usuario_id, descricao, status) VALUES (%s, %s, %s)",
                       (usuario_id, f'Descrição do Pedido {i+1}', 'pending'))
        pedido_id = cursor.lastrowid  # Recuperar o ID do pedido criado

        # Inserir produtos para o pedido
        for produto_id in produtos_ids[i]:
            cursor.execute("INSERT INTO pedidoproduto (pedido_id, produto_id) VALUES (%s, %s)",
                           (pedido_id, produto_id))

    # Commit as transações
    connection.commit()

except Error as e:
    print("Erro ao conectar ao MySQL", e)
finally:
    if connection.is_connected():
        cursor.close()
        connection.close()
        print("Conexão ao MySQL foi encerrada")

